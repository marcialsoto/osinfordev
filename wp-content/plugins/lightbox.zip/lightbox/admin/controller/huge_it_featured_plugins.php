<?php
include_once(HUGEIT_PLUGIN_DIR."/admin/view/huge_it_featured_plugins.php");
?>