<?php
include_once(HUGEIT_PLUGIN_DIR."/admin/model/install_base.php");
?>