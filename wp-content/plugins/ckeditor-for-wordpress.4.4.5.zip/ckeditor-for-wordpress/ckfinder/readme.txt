CKFinder - Ajax File Manager
----------------------------

CKFinder is a commercial file browser that integrates well with CKEditor.
See CKFinder web site for more information: http://ckfinder.com/

Before downloading CKFinder, please read CKFinder license: http://ckfinder.com/license

Installation
------------
1. Download CKFinder for PHP: http://ckfinder.com/download
2. Unpack contents of the "ckfinder" folder to this directory.
3. Rename ckfinder_config.php to config.php(overwrite default config.php distributed with CKFinder)

At the end your folder structure should look like this:

ckeditor-for-wordpress
  ckeditor    <dir>
  ckfinder    <dir>
    _samples  <dir>
    core      <dir>
    userfiles <dir>
    ckfinder.php
    ckfinder.js
    config.php
    ...
You can delete the "_samples" and "userfiles" folders from CKFinder directory.
