﻿/*
 Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","pt",{title:"Seleção da Cor da IU",preview:"Pré-visualização Live ",config:"Colar este item no seu ficheiro config.js",predefined:"Conjuntos de cor predefinidos"});